// content.js
// Runs on every review.opendev.org page. Adds a floating button when a
// change page is detected (URL contains /c/<project>/+/<number>), and on
// click calls the local bot API and shows the result in a modal.
// PolyGerrit is a single-page app with heavy client-side routing, so we
// poll the URL for changes instead of relying on page load events.

const API_BASE = "http://localhost:5000";

let currentChangeNumber = null;
let buttonEl = null;

function extractChangeNumber() {
  const match = window.location.pathname.match(/\/c\/[^/]+\/\+\/(\d+)/);
  return match ? match[1] : null;
}

function createButton() {
  if (buttonEl) return;
  buttonEl = document.createElement("button");
  buttonEl.id = "dd-check-button";
  buttonEl.textContent = "Check divergence";
  buttonEl.onclick = onCheckClick;
  document.body.appendChild(buttonEl);
}

function removeButton() {
  if (buttonEl) {
    buttonEl.remove();
    buttonEl = null;
  }
}

function pollForChangePage() {
  const changeNum = extractChangeNumber();
  if (changeNum !== currentChangeNumber) {
    currentChangeNumber = changeNum;
    if (changeNum) {
      createButton();
    } else {
      removeButton();
    }
  }
  setTimeout(pollForChangePage, 1000);
}

function renderResultHtml(data) {
  if (data.error || data.divergence === "error") {
    const msg = data.error || data.reason || "Unknown error";
    return `<div class="dd-error">Error: ${msg}</div>`;
  }
  if (data.divergence === "divergent") {
    const ps = data.divergent_patchsets ? `Patchset ${data.divergent_patchsets}` : "Patchset unknown";
    const recsHtml = (data.recommendations || [])
      .map((r, i) => `<div class="dd-rec-row">${i + 1}. ${r}</div>`)
      .join("");
    return `
      <div class="dd-divergent-badge">⚠ Divergence detected <span class="dd-ps">(${ps})</span></div>
      <div class="dd-label">Type</div>
      <div class="dd-value">${data.type_category}</div>
      <div class="dd-label">Evidence</div>
      <div class="dd-evidence">"${data.evidence}"</div>
      <div class="dd-label">Recommendations</div>
      <div>${recsHtml}</div>
    `;
  }
  return `<div class="dd-nondivergent-badge">✓ No divergence detected</div>`;
}

function openModal() {
  const overlay = document.createElement("div");
  overlay.id = "dd-modal-overlay";

  const box = document.createElement("div");
  box.id = "dd-modal-box";
  box.innerHTML = `
    <div class="dd-modal-header">Divergence check — change ${currentChangeNumber}</div>
    <div id="dd-modal-body" class="dd-loading">Checking...</div>
    <button id="dd-modal-close">Close</button>
  `;
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  document.getElementById("dd-modal-close").onclick = () => overlay.remove();
  overlay.onclick = (e) => {
    if (e.target === overlay) overlay.remove();
  };

  return document.getElementById("dd-modal-body");
}

async function onCheckClick() {
  if (!currentChangeNumber) return;
  const bodyEl = openModal();

  try {
    const resp = await fetch(
      `${API_BASE}/check_divergence?change_number=${encodeURIComponent(currentChangeNumber)}`
    );
    const data = await resp.json();
    bodyEl.classList.remove("dd-loading");
    bodyEl.innerHTML = renderResultHtml(data);
  } catch (err) {
    bodyEl.classList.remove("dd-loading");
    bodyEl.innerHTML = `<div class="dd-error">Could not reach local API at ${API_BASE}. Is bot_api.py running?</div>`;
  }
}

pollForChangePage();
